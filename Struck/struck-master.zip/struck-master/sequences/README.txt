Please download and unzip tracking sequences from:

http://vision.ucsd.edu/~bbabenko/project_miltrack.html
