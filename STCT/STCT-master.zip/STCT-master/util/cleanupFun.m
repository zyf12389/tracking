function cleanupFun
% fprintf('Runing clean up function\n');
caffe.reset_all();
%caffe.delete_solver([5,4]);
